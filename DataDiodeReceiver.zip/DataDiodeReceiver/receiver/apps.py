from django.apps import AppConfig


class ReceiverConfig(AppConfig):
    name = 'receiver'
