from django.apps import AppConfig


class TransmitterConfig(AppConfig):
    name = 'transmitter'
